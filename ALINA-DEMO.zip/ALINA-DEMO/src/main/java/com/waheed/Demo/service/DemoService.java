package com.waheed.Demo.service;

import com.waheed.Demo.model.Form;
import com.waheed.Demo.repository.FormRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DemoService {

    @Autowired
    private FormRepository formRepository;

    public String saveEmail(Form data){
        formRepository.save(data);
        return "200";
    }
}
