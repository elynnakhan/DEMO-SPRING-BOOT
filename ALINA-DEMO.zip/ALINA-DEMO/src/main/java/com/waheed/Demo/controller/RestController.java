package com.waheed.Demo.controller;

import com.waheed.Demo.model.Form;
import com.waheed.Demo.service.DemoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@org.springframework.web.bind.annotation.RestController
public class RestController {

    @Autowired
    private DemoService demoService;

    // Save operation
    @RequestMapping(value="/form", method= RequestMethod.POST, consumes = "application/json")
    public String saveForm(@RequestBody Form data)
    {
        System.out.println(data);
        return demoService.saveEmail(data);
    }
}
